import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Component implements Blob {
    int label,
        color;
    ArrayList<Pixel> pixels = new ArrayList<>();

//    public Component(int label) {
//        setLabel(label);
//    }


    public void addPoint(Pixel pixel) {
        pixels.add(pixel);
    }

    public void removePoint(Pixel pixel) {
        pixels.remove(pixel);
    }

    public int getColor() {
        return color;
    }

    @Override
    public Point getCentroid() {
        int centroidX = (int) pixels.stream().mapToInt(pixel -> pixel.x).average().orElse(0.0);
        int centroidY = (int) pixels.stream().mapToInt(pixel -> pixel.y).average().orElse(0.0);
        return new Point(centroidX, centroidY);
    }

    @Override
    public int getLabel() {
        return label;
    }

    @Override
    public void setLabel(int label) {
        this.label = label;
    }
}

public class Pixel {
    int x,
        y,
        color;

    double distance;

//    Pixel topLeft,
//          top,
//          topRight,
//          left,
//          right,
//          bottomLeft,
//          bottom,
//          bottomRight;

    public Pixel(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public double getDistance() {
        return distance;
    }

    public int getColor() {
        return color;
    }
}

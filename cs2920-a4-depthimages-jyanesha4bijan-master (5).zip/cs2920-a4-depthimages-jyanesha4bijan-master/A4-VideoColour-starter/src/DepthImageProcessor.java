import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

import static java.lang.Math.abs;

/**
 * Complete this class as part of the assignment
 */
public class DepthImageProcessor implements ImageProcessor {

    int imageWidth;
    int imageHeight;
    int x, y;
    double threshold;

    final static int NOT_VISITED = -99;
    final static int VISITED = -1;
    final static int BACKGROUND = -2;

    double minDist;
    double maxDist;
    ArrayList<Component> currentComponents = new ArrayList<>();

    double[][] rawImg;
    int[][] colorImg;
    int[][] parent;
    //we need to create and arraylist blob
//    ArrayList<Blob> myBlobs = new ArrayList<>();


    @Override
    public void processFile(String fileString) { //do not throw anything here{

        // Process Raw Image
        try {
            Scanner sc = new Scanner(new File(fileString));
            imageWidth = sc.nextInt();
            imageHeight = sc.nextInt();

            rawImg = new double[imageHeight][imageWidth];

            // CREATE RAW IMAGE
            int row = 0;
            int col = 0;
            double pixel;
            while (sc.hasNextDouble()) {
                pixel = sc.nextDouble();
                rawImg[row][col] = pixel;

                col++;
                // next row
                if (col == imageWidth) {
                    row++;
                    col = 0;
                }
            }
            //initializing the color array with a single color
            int[][]colormi = new int[imageHeight][imageWidth];
            for (x = 0; x < imageHeight; x++) {
                for (y = 0; y < imageWidth; y++) {
                    colormi[x][y]=0x778899;
                }}
                colorImg=colormi;
            // Process Colour Image
            connectedComponents();

        } catch (FileNotFoundException e) {
            System.out.println(e);
        }
    }

    @Override
    public double[][] getRawImg() {
        return rawImg;
    }
    int[][] flag;

    public void connectedComponents() {
        int count = 0;


        flag = new int[imageHeight][imageWidth];
        for (x = 0; x < imageHeight; x++) {
            for (y = 0; y < imageWidth; y++) {
                flag[x][y] = NOT_VISITED; // Setting it to an extreme value to check if every 'node' is visited
            }
        } //initialising flag

        for (x = 0; x < imageHeight; x++) {
            for (y = 0; y < imageWidth; y++) {
                if (flag[x][y] == NOT_VISITED && isForeground(x,y)) {
                    dfs(x, y, flag);

                    count++;
                }
            }
        }
      //  return count;//returning the total number of connected components

    }

    public void dfs(int x, int y, int[][] myflag) {
        Point point = new Point(x, y);
        Stack<Point> stack = new Stack<>();
        Component component = new Component();
        int row[] = {-1, -1, -1, 0, 0, 1, 1, 1};
        int col[] = {-1, 0, 1, -1, 1, -1, 0, 1};

        // Initialize Stack; Maybe could start with a do while loop?
        stack.push(point);

        while (!stack.empty()) {
            point = stack.pop();

            // Skip if already visited
            if (myflag[point.x][point.y] == VISITED) continue;
            // Set flag to background
            if (!isForeground(point.x, point.y)) {
                myflag[point.x][point.y] = BACKGROUND;
                continue;
            }

            // Add current pixel to component
            component.addPoint(new Pixel(point.x, point.y));
            // Mark visited;
            myflag[point.x][point.y] = VISITED;
            int currentX = point.x;
            int currentY = point.y;

            // Check neighbours (8-ways)
            for (int neighbour = 0; neighbour < 8; neighbour++) {

                int nextX = currentX + row[neighbour];
                int nextY = currentY + col[neighbour];

                if (isInBounds(nextX, nextY)) {
                    if (isSameComponent(point.x, point.y, nextX, nextY)) {
                        //myflag[nextX][nextY] = VISITED;
                        stack.add(new Point(nextX, nextY));

                    }

                }
            }


        }

        // When the stack is exhausted for DFS - add this completed component to the Blob
        currentComponents.add(component);

    }

//
//    private void dfs(int[][] visited) {
//        int componentLabel = 1; // We're going to start our components at 1 - the 0th component we can reserve for -1 values (and -99 we can use to check for errors)
//
//
//        Queue<Pixel> queue = new LinkedList<>();
//        queue.add(new Pixel(0, 0));
//        visited[0][0] = VISITED;
//
//        // This method was used from GeegsForGeeks.org by PrinciRaj1992, 29AjayKumar
//        // Note: I particularly liked the way they use two arrays row/col with isSafe - really makes the code nicer to look at (rather than having to type out all the edge cases)
//
//        int row[] = {-1, -1, -1, 0, 0, 1, 1, 1};
//        int col[] = {-1, 0, 1, -1, 1, -1, 0, 1};
//
//        while (!queue.isEmpty()) {
//            int currentX = queue.peek().x;
//            int currentY = queue.peek().y;
//
//            for (int k = 0; k < 8; k++) {
//
//                int nextX = currentX + row[k];
//                int nextY = currentY + col[k];
//
//                if (isSafe(nextX, nextY, visited)) {
//                    if (isSameComponent(currentX, currentY, nextX, nextY)) {
//
//                    }
//                    visited[nextX][nextY] = VISITED;
//                    queue.add(new Pixel(nextX, nextY));
//                }
//            }
//        }
//
//    }

    private boolean isSameComponent(int x, int y, int nextX, int nextY) {
            return abs(rawImg[x][y] - rawImg[nextX][nextY]) < threshold;
    }

    private boolean isForeground(int x, int y) {
        return (rawImg[x][y] >= minDist && rawImg[x][y] <= maxDist);
    }

    private boolean isInBounds(int i, int j) {
        return
                // First Row
                (i >= 0) &&
                        // Last Row
                        (i < imageHeight) &&
                        // First Column
                        (j >= 0) &&
                        // Last Column
                        (j < imageWidth);

    }

    //each time we get a connected component we would add it to myblobs array list
    //so technically a pixel on the 2d array would be assigned a color based on the blob position in the myblobs array
    @Override
    public int[][] getColorImg() {
              for (Component b : currentComponents) {
                      ArrayList<Pixel> mypixels= b.pixels;
                       for (Pixel p : mypixels){
                           colorImg[p.x][p.y]=COLORS[currentComponents.indexOf(b)];
                       }
                }

        return colorImg;
    }

    @Override
    public ArrayList<Blob> getBlobs() {
        ArrayList<Blob> blobs = new ArrayList<>();

        for (Component component : currentComponents) {
            //for each component set the label as it's index position in the array
            component.setLabel(currentComponents.indexOf(component));
            blobs.add(component);
        }
        currentComponents.clear(); //clearing the arraylist as it was being appended after each frames

        return blobs;
    }

    @Override
    public void setThreshold(double threshold) {
        this.threshold = threshold;    //just a setter that set's the threshold
    }

    @Override
    public int getWidth() {
        return imageWidth; //works as test case passed
    }

    @Override
    public int getHeight() {
        return imageHeight; //works as test case passed
    }

    @Override
    public void setMinDist(double minDist) {
        this.minDist = minDist;
    }

    @Override
    public void setMaxDist(double maxDist) {
        this.maxDist = maxDist;
    }

}
